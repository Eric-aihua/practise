package com.demo.spring.util;

public class Constants {
	public final static String USERNAME_KEY = "username";

}
