package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_ko extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "\uC138\uBD80 \uC815\uBCF4" },
            { "FileChooser.detailsViewButtonAccessibleName", "\uC138\uBD80 \uC815\uBCF4" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "\uC138\uBD80 \uC815\uBCF4" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "\uC18D\uC131" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "\uC218\uC815 \uB0A0\uC9DC" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "\uC774\uB984" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "\uD30C\uC77C \uC774\uB984(&N):" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "\uD06C\uAE30" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "\uC720\uD615" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "\uD30C\uC77C \uC720\uD615(&T):" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "\uD3F4\uB354 \uC774\uB984(&N):" },
            { "FileChooser.homeFolderAccessibleName", "\uD648" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "\uD648" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "\uBAA9\uB85D" },
            { "FileChooser.listViewButtonAccessibleName", "\uBAA9\uB85D" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "\uBAA9\uB85D" },
            { "FileChooser.lookInLabel.textAndMnemonic", "\uCC3E\uB294 \uC704\uCE58(&I):" },
            { "FileChooser.newFolderAccessibleName", "\uC0C8 \uD3F4\uB354" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "\uC0C8 \uD3F4\uB354" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "\uC0C8 \uD3F4\uB354 \uC0DD\uC131" },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "\uC0C8\uB85C \uACE0\uCE68" },
            { "FileChooser.saveInLabel.textAndMnemonic", "\uC800\uC7A5 \uC704\uCE58:" },
            { "FileChooser.upFolderAccessibleName", "\uC704\uB85C" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "\uD55C \uB808\uBCA8 \uC704\uB85C" },
            { "FileChooser.viewMenuButtonAccessibleName", "\uBCF4\uAE30 \uBA54\uB274" },
            { "FileChooser.viewMenuButtonToolTipText", "\uBCF4\uAE30 \uBA54\uB274" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "\uBCF4\uAE30" },
        };
    }
}
