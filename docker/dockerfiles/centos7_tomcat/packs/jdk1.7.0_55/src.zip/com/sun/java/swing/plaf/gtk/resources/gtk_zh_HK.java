package com.sun.java.swing.plaf.gtk.resources;

import java.util.ListResourceBundle;

public final class gtk_zh_HK extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.acceptAllFileFilter.textAndMnemonic", "\u6240\u6709\u6A94\u6848" },
            { "FileChooser.cancelButton.textAndMnemonic", "\u53D6\u6D88(&C)" },
            { "FileChooser.cancelButtonToolTip.textAndMnemonic", "\u4E2D\u6B62\u6A94\u6848\u9078\u64C7\u5668\u5C0D\u8A71\u65B9\u584A\u3002" },
            { "FileChooser.deleteFileButton.textAndMnemonic", "\u522A\u9664\u6A94\u6848(&L)" },
            { "FileChooser.filesLabel.textAndMnemonic", "\u6A94\u6848(&F)" },
            { "FileChooser.filterLabel.textAndMnemonic", "\u7BE9\u9078:" },
            { "FileChooser.foldersLabel.textAndMnemonic", "\u8CC7\u6599\u593E(&D)" },
            { "FileChooser.newFolderButton.textAndMnemonic", "\u65B0\u5EFA\u8CC7\u6599\u593E(&N)" },
            { "FileChooser.newFolderDialog.textAndMnemonic", "\u8CC7\u6599\u593E\u540D\u7A31:" },
            { "FileChooser.newFolderNoDirectoryError.textAndMnemonic", "\u5EFA\u7ACB\u76EE\u9304 \"{0}\" \u6642\u767C\u751F\u932F\u8AA4: \u6C92\u6709\u6B64\u6A94\u6848\u6216\u76EE\u9304" },
            { "FileChooser.newFolderNoDirectoryErrorTitle.textAndMnemonic", "\u932F\u8AA4" },
            { "FileChooser.openButton.textAndMnemonic", "\u78BA\u5B9A(&O)" },
            { "FileChooser.openButtonToolTip.textAndMnemonic", "\u958B\u555F\u9078\u53D6\u7684\u6A94\u6848\u3002" },
            { "FileChooser.openDialogTitle.textAndMnemonic", "\u958B\u555F" },
            { "FileChooser.pathLabel.textAndMnemonic", "\u9078\u53D6(&S):" },
            { "FileChooser.renameFileButton.textAndMnemonic", "\u91CD\u65B0\u547D\u540D\u6A94\u6848(&R)" },
            { "FileChooser.renameFileDialog.textAndMnemonic", "\u5C07\u6A94\u6848 \"{0}\" \u91CD\u65B0\u547D\u540D\u70BA" },
            { "FileChooser.renameFileError.textAndMnemonic", "\u5C07\u6A94\u6848 \"{0}\" \u91CD\u65B0\u547D\u540D\u70BA \"{1}\" \u6642\u51FA\u73FE\u932F\u8AA4" },
            { "FileChooser.renameFileError.titleAndMnemonic", "\u932F\u8AA4" },
            { "FileChooser.saveButton.textAndMnemonic", "\u78BA\u5B9A(&O)" },
            { "FileChooser.saveButtonToolTip.textAndMnemonic", "\u5132\u5B58\u9078\u53D6\u7684\u6A94\u6848\u3002" },
            { "FileChooser.saveDialogTitle.textAndMnemonic", "\u5132\u5B58" },
            { "GTKColorChooserPanel.blue.textAndMnemonic", "\u85CD(&B):" },
            { "GTKColorChooserPanel.color.textAndMnemonic", "\u984F\u8272\u540D\u7A31(&N):" },
            { "GTKColorChooserPanel.green.textAndMnemonic", "\u7DA0(&G):" },
            { "GTKColorChooserPanel.hue.textAndMnemonic", "\u8272\u8ABF(&H):" },
            { "GTKColorChooserPanel.red.textAndMnemonic", "\u7D05(&E):" },
            { "GTKColorChooserPanel.saturation.textAndMnemonic", "\u5F69\u5EA6(&S):" },
            { "GTKColorChooserPanel.textAndMnemonic", "GTK \u8272\u5F69\u9078\u64C7\u5668(&G)" },
            { "GTKColorChooserPanel.value.textAndMnemonic", "\u503C(&V):" },
        };
    }
}
