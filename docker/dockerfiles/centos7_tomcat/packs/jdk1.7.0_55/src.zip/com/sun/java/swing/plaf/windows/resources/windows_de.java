package com.sun.java.swing.plaf.windows.resources;

import java.util.ListResourceBundle;

public final class windows_de extends ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "FileChooser.detailsViewActionLabel.textAndMnemonic", "Details" },
            { "FileChooser.detailsViewButtonAccessibleName", "Details" },
            { "FileChooser.detailsViewButtonToolTip.textAndMnemonic", "Details" },
            { "FileChooser.fileAttrHeader.textAndMnemonic", "Attribute" },
            { "FileChooser.fileDateHeader.textAndMnemonic", "Ge\u00E4ndert" },
            { "FileChooser.fileNameHeader.textAndMnemonic", "Name" },
            { "FileChooser.fileNameLabel.textAndMnemonic", "&Dateiname:" },
            { "FileChooser.fileSizeHeader.textAndMnemonic", "Gr\u00F6\u00DFe" },
            { "FileChooser.fileTypeHeader.textAndMnemonic", "Typ" },
            { "FileChooser.filesOfTypeLabel.textAndMnemonic", "Datei&typ:" },
            { "FileChooser.folderNameLabel.textAndMnemonic", "Ordner&name:" },
            { "FileChooser.homeFolderAccessibleName", "Home" },
            { "FileChooser.homeFolderToolTip.textAndMnemonic", "Home" },
            { "FileChooser.listViewActionLabel.textAndMnemonic", "Liste" },
            { "FileChooser.listViewButtonAccessibleName", "Liste" },
            { "FileChooser.listViewButtonToolTip.textAndMnemonic", "Liste" },
            { "FileChooser.lookInLabel.textAndMnemonic", "Suchen &in:" },
            { "FileChooser.newFolderAccessibleName", "Neuer Ordner" },
            { "FileChooser.newFolderActionLabel.textAndMnemonic", "Neuer Ordner" },
            { "FileChooser.newFolderToolTip.textAndMnemonic", "Neuen Ordner erstellen" },
            { "FileChooser.refreshActionLabel.textAndMnemonic", "Aktualisieren" },
            { "FileChooser.saveInLabel.textAndMnemonic", "Speichern in:" },
            { "FileChooser.upFolderAccessibleName", "Nach oben" },
            { "FileChooser.upFolderToolTip.textAndMnemonic", "Eine Ebene h\u00F6her" },
            { "FileChooser.viewMenuButtonAccessibleName", "Ansichtsmen\u00FC" },
            { "FileChooser.viewMenuButtonToolTipText", "Ansichtsmen\u00FC" },
            { "FileChooser.viewMenuLabel.textAndMnemonic", "Ansicht" },
        };
    }
}
